﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Web.UI;

namespace FileUploadPoc.FileUpload
{
    public partial class FileUploadControl : UserControl
    {
        #region Private fields

        private byte[] CurrentFileContents { get; set; }
        private byte[] CurrentFileHash { get; set; }

        #endregion

        #region Public Properties

        
        public string FileType { get; set; }

        public string[] Environments { get; set; }

        public string UserName { get; set; }

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region Events

        protected void OnBlur(object sender, EventArgs e)
        {
            GenerateHash();

            GetFileSize();
        }
        #endregion

        #region Helpers


        private void GetFileSize()
        {
            if (FileUpload.HasFiles)
            {
                // set the file size text box
                FileSizeTextBox.Text = FileUpload.FileBytes.Length.BytesToString();
            }
        }

        private void GenerateHash()
        {
           if(FileUpload.HasFiles)
            {
                // get the file content
                CurrentFileContents = FileUpload.FileBytes;

               

                // get the sha256 hash and set the text box
                using (SHA256Managed Sha = new SHA256Managed())
                {
                    CurrentFileHash = Sha.ComputeHash(CurrentFileContents);
                    HashTextBox.Text = string.Concat(CurrentFileHash.Select(b => string.Format("{0:X2}", b)));
                }
            }
        }

        #endregion
    }

    public static class Helpers
    {
        public static string BytesToString(this int byteCount)
        {
            string[] suf = { "B", "KB", "MB", "GB", "TB", "PB", "EB" }; //Longs run out around EB
            if (byteCount == 0)
                return "0" + suf[0];
            long bytes = Math.Abs(byteCount);
            int place = Convert.ToInt32(Math.Floor(Math.Log(bytes, 1024)));
            double num = Math.Round(bytes / Math.Pow(1024, place), 1);
            return (Math.Sign(byteCount) * num).ToString() + suf[place];
        }
    }
}